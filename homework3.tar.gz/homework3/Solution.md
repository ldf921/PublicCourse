## Homework3 
Liu, Dingfeng, 2014011376. 
### Problem 1
See codes in rotation/ 
### Problem 2
See the chessboard/distort.cc and chessboard/distort.png.
### Problem 3
See pointcloud/main.cc and pointcloud/ground.jpg. A threshold is used by looking at the histogram of lowest height in each pixel.
